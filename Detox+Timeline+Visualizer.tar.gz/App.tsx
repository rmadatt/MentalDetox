import { useEffect, useState, useMemo, useRef } from "react";
import {
  AreaChart, Area, XAxis, YAxis, ResponsiveContainer, Tooltip as ReTooltip,
  PieChart, Pie, Cell
} from "recharts";

// Types
type BaseEvent = {
  id: string;
  date: string; // ISO
  label: string;
  detail: string;
  type: "breadcrumb" | "block1" | "unblock" | "secret" | "detox_start" | "detox_mid" | "return" | "hard_block" | "custom";
  intensity?: number;
};

type RecordNote = {
  date: string;
  note: string;
};

const BASE_EVENTS: BaseEvent[] = [
  { id: "e1", date: "2024-06-03", label: "Breadcrumbing starts", detail: "Main account - low investment signals, intermittent replies", type: "breadcrumb", intensity: 72 },
  { id: "e2", date: "2024-06-09", label: "Block #1", detail: "First withdrawal - tests your response to absence", type: "block1", intensity: 88 },
  { id: "e3", date: "2024-06-11", label: "Unblock", detail: "24-48h later - reward after punishment", type: "unblock", intensity: 84 },
  { id: "e4", date: "2026-04-26", label: "Secret account DIRECT", detail: "Riddles + identity reveal test - escalation & secrecy", type: "secret", intensity: 78 },
  { id: "e5", date: "2026-07-13", label: "Mental Detox START", detail: "You take space - breaking the reinforcement loop", type: "detox_start", intensity: 62 },
  { id: "e5b", date: "2026-08-20", label: "Healing in progress", detail: "Detox midpoint - nervous system recalibrating", type: "detox_mid", intensity: 32 },
  { id: "e6", date: "2026-10-26", label: "Return from detox", detail: "After 105 days - re-entry", type: "return", intensity: 58 },
  { id: "e7", date: "2026-10-29", label: "Hard Block #2", detail: "Identity hide + Door Ajar (partial block) - rapid devaluation in 3 days", type: "hard_block", intensity: 12 },
];

const TYPE_META: Record<string, { color: string; bg: string; dot: string; label: string }> = {
  breadcrumb: { color: "#2a9d8f", bg: "#d8f3dc", dot: "bg-[#2a9d8f]", label: "Breadcrumbing" },
  block1: { color: "#e76f51", bg: "#fde8e1", dot: "bg-[#e76f51]", label: "Block" },
  unblock: { color: "#2a9d8f", bg: "#e8f5e9", dot: "bg-[#2a9d8f]", label: "Unblock" },
  secret: { color: "#6c5ce7", bg: "#ede9fe", dot: "bg-[#6c5ce7]", label: "Testing" },
  detox_start: { color: "#2a9d8f", bg: "#d8f3dc", dot: "bg-[#2a9d8f]", label: "Detox" },
  detox_mid: { color: "#2a9d8f", bg: "#b7e4c7", dot: "bg-[#2a9d8f]", label: "Healing" },
  return: { color: "#f4a261", bg: "#fef3c7", dot: "bg-[#f4a261]", label: "Return" },
  hard_block: { color: "#264653", bg: "#e8eef0", dot: "bg-[#264653]", label: "Hard Block" },
  custom: { color: "#264653", bg: "#ffffff", dot: "bg-[#264653]", label: "Your note" },
};

// Helper API
async function callApi(action: string, args: any) {
  const res = await fetch("actions", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ action, args }),
  });
  const json = await res.json();
  if (!res.ok || json.error) throw new Error(json.error || `API ${action} failed`);
  return json.data;
}

export default function App() {
  const [customNotes, setCustomNotes] = useState<{ id: string; value: RecordNote; created_at: string }[]>([]);
  const [selectedId, setSelectedId] = useState<string>("e5");
  const [hoveredId, setHoveredId] = useState<string | null>(null);
  const [newDate, setNewDate] = useState("");
  const [newNote, setNewNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [saveInfo, setSaveInfo] = useState<string | null>(null);

  const scrollRef = useRef<HTMLDivElement>(null);

  // Load records
  useEffect(() => {
    (async () => {
      try {
        const data = await callApi("records.list", { collection: "timeline_notes" });
        const records = (data?.records || []) as any[];
        setCustomNotes(records.map(r => ({ id: r.id, value: r.value as RecordNote, created_at: r.created_at })));
      } catch {
        // API unavailable in preview - ignore
      }
    })();
  }, []);

  const allEvents: BaseEvent[] = useMemo(() => {
    const customAsEvents: BaseEvent[] = customNotes.map(n => ({
      id: n.id,
      date: n.value.date,
      label: n.value.note.slice(0, 32),
      detail: n.value.note,
      type: "custom" as const,
    }));
    const merged = [...BASE_EVENTS, ...customAsEvents];
    return merged.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }, [customNotes]);

  const selectedEvent = useMemo(() => allEvents.find(e => e.id === selectedId) || allEvents.find(e => e.type === "hard_block") || allEvents[0], [selectedId, allEvents]);

  // Emotional intensity data for chart
  const emotionalData = useMemo(() => {
    return allEvents.map(e => {
      if (e.intensity !== undefined) return { date: e.date.slice(5), fullDate: e.date, intensity: e.intensity, label: e.label, type: e.type };
      return { date: e.date.slice(5), fullDate: e.date, intensity: 45, label: e.label, type: e.type };
    });
  }, [allEvents]);

  // Donut data
  const donutData = [
    { name: "Sweet (breadcrumbing, validation)", value: 156, color: "#2a9d8f" },
    { name: "Sharp (blocks, tests, riddles)", value: 39, color: "#e76f51" },
  ];

  const handleAddNote = async () => {
    if (!newDate || !newNote.trim()) {
      setSaveError("Add both a date and a note.");
      return;
    }
    setBusy(true);
    setSaveError(null);
    setSaveInfo(null);
    try {
      const idempotency_key = `note-${newDate}-${newNote.slice(0,20)}-${Date.now()}`;
      const created = await callApi("records.create", {
        collection: "timeline_notes",
        value: { date: newDate, note: newNote.trim() } as RecordNote,
        idempotency_key,
      });
      setCustomNotes(prev => [...prev, { id: created.id, value: created.value, created_at: created.created_at }]);
      setNewNote("");
      setNewDate("");
      setSaveInfo("Note added to your timeline.");
      setTimeout(() => setSaveInfo(null), 2500);
    } catch (e: any) {
      setSaveError(e.message || "Could not save");
    } finally {
      setBusy(false);
    }
  };

  const handleDeleteNote = async (id: string) => {
    try {
      await callApi("records.delete", { collection: "timeline_notes", id });
      setCustomNotes(prev => prev.filter(n => n.id !== id));
    } catch (e: any) {
      setSaveError(e.message);
    }
  };

  // Timeline position calculations - use index based spacing but widen detox
  const getPositionPercent = (index: number) => {
    const total = allEvents.length;
    if (total <= 1) return 0;
    return (index / (total - 1)) * 100;
  };

  const detoxStartIdx = allEvents.findIndex(e => e.type === "detox_start");
  const detoxEndIdx = allEvents.findIndex(e => e.type === "return");
  const detoxStartPct = detoxStartIdx >= 0 ? getPositionPercent(detoxStartIdx) : 0;
  const detoxEndPct = detoxEndIdx >= 0 ? getPositionPercent(detoxEndIdx) : 100;

  return (
    <div data-safe-area-inset-root className="min-h-screen w-full bg-[var(--bg)] text-[var(--ink)]" style={{ boxSizing: "border-box", paddingTop: "var(--safe-area-inset-top)" }}>
      {/* Top sticky header */}
      <header data-safe-area-sticky-top className="sticky z-30 backdrop-blur-xl bg-[var(--bg)]/80 border-b border-[var(--border)]" style={{ top: "var(--safe-area-inset-top)" }}>
        <div className="mx-auto max-w-[1120px] px-5 md:px-8 h-[64px] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-[#264653] text-white flex items-center justify-center font-bold text-[13px] serif">Y</div>
            <span className="text-[13px] tracking-[0.12em] uppercase font-semibold opacity-60">Private Worksheet</span>
          </div>
          <div className="flex items-center gap-2 text-[12px]">
            <span className="hidden md:inline opacity-50">105 days detox • 3 days to block</span>
            <span className="w-2 h-2 rounded-full bg-[#2a9d8f] animate-pulse" />
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-[1120px] px-5 md:px-8 pb-24">
        {/* Title */}
        <div className="pt-10 md:pt-14 pb-8">
          <h1 className="serif text-[32px] md:text-[48px] leading-[0.95] tracking-[-0.02em] font-bold max-w-[640px]">
            Your Timeline: <span className="text-[#2a9d8f]">Detox, Return,</span> and Control
          </h1>
          <p className="mt-4 text-[15px] md:text-[17px] leading-relaxed text-[var(--ink-muted)] max-w-[640px]">
            A visual map of intermittent reinforcement. This worksheet helps you see the pattern, not just feel it.
          </p>

          {/* Insight callout */}
          <div className="mt-6 md:mt-8 grid md:grid-cols-[1.15fr_0.85fr] gap-4">
            <div className="rounded-[16px] bg-[var(--surface)] border border-[var(--border)] p-5 md:p-6 shadow-[var(--shadow)]">
              <div className="flex items-start gap-3">
                <div className="mt-0.5 w-7 h-7 rounded-full bg-[#d8f3dc] flex items-center justify-center text-[#2a9d8f]">✦</div>
                <div>
                  <p className="text-[13px] uppercase tracking-[0.12em] font-semibold opacity-60 mb-2">Clinical Insight</p>
                  <p className="text-[14.5px] leading-[1.6]">
                    <span className="font-semibold">Detox broke the intermittent reinforcement loop.</span> After 105 days of nervous system recalibration (July 13 → Oct 26), return triggered <span className="bg-[#fde8e1] px-1.5 py-0.5 rounded font-medium">rapid devaluation — only 3 days from return to hard block</span>. This compression is characteristic of control dynamics reasserting after a boundary.
                  </p>
                </div>
              </div>
            </div>
            <div className="rounded-[16px] bg-[#264653] text-[#e8eeef] p-5 md:p-6 flex flex-col justify-between">
              <div>
                <p className="text-[12px] uppercase tracking-[0.15em] opacity-60 font-semibold">Loop Duration</p>
                <p className="serif text-[28px] font-bold mt-1">156 → 39</p>
                <p className="text-[13px] opacity-70 leading-relaxed mt-1">Sweet messages kept you in orbit. Sharp signals kept you anxious. That 4:1 ratio is textbook variable reward.</p>
              </div>
              <div className="mt-4 flex gap-2">
                <span className="text-[11px] px-2.5 py-1 rounded-full bg-white/10 border border-white/10">Intermittent Reinforcement</span>
                <span className="text-[11px] px-2.5 py-1 rounded-full bg-white/10 border border-white/10">Devaluation</span>
              </div>
            </div>
          </div>
        </div>

        {/* Timeline Section */}
        <section className="mt-2 rounded-[20px] bg-[var(--surface)] border border-[var(--border)] shadow-[var(--shadow)] overflow-hidden">
          <div className="px-6 md:px-8 py-6 border-b border-[var(--border)] flex flex-wrap items-center justify-between gap-3">
            <h2 className="serif text-[20px] font-semibold flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-[#2a9d8f] text-white flex items-center justify-center text-[12px]">1</span>
              Chronology & Healing Zone
            </h2>
            <div className="flex items-center gap-4 text-[11px]">
              <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded-full bg-[#d8f3dc] border border-[#b7e4c7] block" /> Detox (Green Healing Zone)</span>
              <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-[#e76f51] block" /> Punishment</span>
              <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-[#264653] block" /> Hard Block</span>
            </div>
          </div>

          {/* Horizontal timeline */}
          <div className="relative">
            <div ref={scrollRef} className="overflow-x-auto overflow-y-visible px-6 md:px-8 py-10 scrollbar-thin">
              <div className="relative min-w-[860px] h-[168px]">
                {/* base line */}
                <div className="absolute top-[56px] left-0 right-0 h-[2px] bg-[var(--border)]" />
                {/* detox shaded zone */}
                <div
                  className="absolute top-[24px] bottom-[36px] bg-[#d8f3dc]/70 border-x border-[#b7e4c7]/60 backdrop-blur-[1px]"
                  style={{ left: `${detoxStartPct}%`, width: `${Math.max(8, detoxEndPct - detoxStartPct)}%` }}
                >
                  <div className="absolute -top-5 left-1/2 -translate-x-1/2 whitespace-nowrap text-[10px] tracking-[0.12em] uppercase font-semibold text-[#2a9d8f] bg-[#d8f3dc] px-2 py-0.5 rounded-full border border-[#b7e4c7]">
                    🌿 105-day healing
                  </div>
                  <div className="absolute inset-0 opacity-[0.18]" style={{ backgroundImage: `repeating-linear-gradient(45deg, #2a9d8f 0 1px, transparent 1px 8px)` }} />
                </div>

                {/* markers */}
                {allEvents.map((ev, idx) => {
                  const pct = getPositionPercent(idx);
                  const isSelected = selectedId === ev.id;
                  const isHovered = hoveredId === ev.id;
                  const meta = TYPE_META[ev.type] || TYPE_META.custom;
                  const isDetoxMid = ev.type === "detox_mid";
                  return (
                    <div
                      key={ev.id}
                      className="absolute top-0 flex flex-col items-center"
                      style={{ left: `${pct}%`, transform: "translateX(-50%)" }}
                      onMouseEnter={() => setHoveredId(ev.id)}
                      onMouseLeave={() => setHoveredId(null)}
                    >
                      <button
                        onClick={() => setSelectedId(ev.id)}
                        className={`group relative z-10 transition-all duration-200 ${isSelected ? "scale-110" : "hover:scale-105"} ${isDetoxMid ? "opacity-60" : ""}`}
                        style={{ marginTop: ev.type === "hard_block" ? "0px" : "0px" }}
                      >
                        <div
                          className={`w-[14px] h-[14px] md:w-[16px] md:h-[16px] rounded-full border-[3px] border-white shadow-[0_2px_8px_rgba(0,0,0,0.12)] ${isSelected ? "ring-2 ring-offset-2 ring-[#264653]" : ""}`}
                          style={{ background: meta.color }}
                        />
                        {/* stem */}
                        <div className="absolute top-[14px] left-1/2 -translate-x-1/2 w-[1px] h-[10px] bg-[var(--border)]" />
                      </button>

                      <div className={`mt-4 text-center max-w-[112px] transition-all ${isSelected ? "opacity-100" : "opacity-80"}`}>
                        <p className="text-[10px] tracking-[0.08em] uppercase font-semibold text-[var(--ink-muted)] leading-none">{ev.date}</p>
                        <p className={`mt-1 text-[12px] leading-[1.15] font-medium ${isSelected ? "text-[var(--ink)]" : ""}`} style={{ color: isSelected ? meta.color : undefined }}>{ev.label}</p>
                      </div>

                      {/* tooltip */}
                      {(isHovered || isSelected) && (
                        <div className="absolute top-[88px] left-1/2 -translate-x-1/2 z-20 w-[220px] p-3 rounded-[12px] bg-[var(--ink)] text-white text-[12px] leading-[1.4] shadow-xl pointer-events-none">
                          <p className="font-semibold">{ev.label}</p>
                          <p className="opacity-80 mt-1">{ev.detail}</p>
                          <p className="mt-2 text-[10px] opacity-50 uppercase tracking-widest">{ev.date} • {meta.label}</p>
                          <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-2 h-2 bg-[var(--ink)] rotate-45" />
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* selected detail */}
            <div className="px-6 md:px-8 pb-6">
              <div className="rounded-[14px] bg-[var(--surface-2)] border border-[var(--border)] p-4 flex flex-wrap gap-4 items-center">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full flex items-center justify-center text-white text-[14px]" style={{ background: TYPE_META[selectedEvent.type]?.color || "#264653" }}>
                    {selectedEvent.type === "hard_block" ? "✕" : "•"}
                  </div>
                  <div>
                    <p className="text-[13px] font-semibold">{selectedEvent.label} — {selectedEvent.date}</p>
                    <p className="text-[12px] text-[var(--ink-muted)] max-w-[560px]">{selectedEvent.detail}</p>
                  </div>
                </div>
                <div className="ml-auto flex items-center gap-2">
                  <span className="text-[11px] px-2.5 py-1 rounded-full bg-white border border-[var(--border)]">Intensity: {selectedEvent.intensity ?? 45}/100</span>
                  {selectedEvent.type === "custom" && (
                    <button onClick={() => handleDeleteNote(selectedEvent.id)} className="text-[11px] px-2.5 py-1 rounded-full bg-[#fde8e1] text-[#a43d24] border border-[#f8c4b4] hover:bg-[#f8c4b4] transition">Remove</button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Middle: Emotional Intensity + Donut */}
        <div className="mt-6 grid lg:grid-cols-[1.2fr_0.8fr] gap-6">
          {/* Emotional curve */}
          <section className="rounded-[20px] bg-[var(--surface)] border border-[var(--border)] shadow-[var(--shadow)] p-6 md:p-7">
            <div className="flex items-start justify-between gap-4">
              <div>
                <h3 className="serif text-[18px] font-semibold flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-[#e8eef0] text-[#264653] flex items-center justify-center text-[12px]">2</span>
                  Emotional Intensity Curve
                </h3>
                <p className="text-[12px] text-[var(--ink-muted)] mt-1 max-w-[420px]">High during breadcrumbing → drops in detox → spikes on return → crashes on hard block. Your nervous system, mapped.</p>
              </div>
              <div className="hidden md:flex gap-2">
                <span className="text-[10px] px-2 py-1 rounded-full bg-[#fde8e1] text-[#8a3a25]">Anxiety</span>
                <span className="text-[10px] px-2 py-1 rounded-full bg-[#d8f3dc] text-[#1d6a5f]">Calm</span>
              </div>
            </div>

            <div className="mt-6 h-[220px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={emotionalData} margin={{ left: 0, right: 12, top: 10, bottom: 0 }}>
                  <defs>
                    <linearGradient id="intensity" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#2a9d8f" stopOpacity={0.28} />
                      <stop offset="100%" stopColor="#2a9d8f" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="date" tick={{ fontSize: 10, fill: "#8aa0a8" }} axisLine={false} tickLine={false} />
                  <YAxis domain={[0, 100]} tick={{ fontSize: 10, fill: "#8aa0a8" }} axisLine={false} tickLine={false} width={28} />
                  <ReTooltip
                    content={({ active, payload }) => {
                      if (!active || !payload?.[0]) return null;
                      const d = payload[0].payload;
                      return (
                        <div className="rounded-[10px] bg-[#1d2a2f] text-white px-3 py-2 text-[11px] shadow-xl">
                          <p className="font-semibold">{d.label}</p>
                          <p className="opacity-70">{d.fullDate} • {d.intensity}/100</p>
                        </div>
                      );
                    }}
                  />
                  <Area type="monotone" dataKey="intensity" stroke="#2a9d8f" strokeWidth={2.5} fill="url(#intensity)" dot={({ cx, cy, payload }: any) => {
                    const color = payload.type === "hard_block" ? "#264653" : payload.type === "detox_start" || payload.type === "detox_mid" ? "#2a9d8f" : payload.type === "block1" ? "#e76f51" : "#a0b8be";
                    return <circle key={payload.fullDate} cx={cx} cy={cy} r={payload.type === "hard_block" ? 6 : 4} fill={color} stroke="#fff" strokeWidth={2} />;
                  }} />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            <div className="mt-4 grid grid-cols-3 gap-2 text-[11px]">
              <div className="rounded-[10px] bg-[#fdf2f0] border border-[#fde8e1] p-3">
                <p className="font-semibold text-[#a43d24]">Breadcrumbing Peak</p>
                <p className="opacity-70 mt-0.5">Dopamine spikes from variable reward keep you checking.</p>
              </div>
              <div className="rounded-[10px] bg-[#d8f3dc]/70 border border-[#b7e4c7] p-3">
                <p className="font-semibold text-[#1d6a5f]">Detox Valley</p>
                <p className="opacity-70 mt-0.5">Cortisol drops. Clarity returns. Loop weakens.</p>
              </div>
              <div className="rounded-[10px] bg-[#e8eef0] border border-[var(--border)] p-3">
                <p className="font-semibold text-[#264653]">Hard Block Crash</p>
                <p className="opacity-70 mt-0.5">3-day collapse from 58 → 12. Control, not disinterest.</p>
              </div>
            </div>
          </section>

          {/* Donut */}
          <section className="rounded-[20px] bg-[var(--surface)] border border-[var(--border)] shadow-[var(--shadow)] p-6 md:p-7 flex flex-col">
            <h3 className="serif text-[18px] font-semibold flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-[#fde8e1] text-[#e76f51] flex items-center justify-center text-[12px]">3</span>
              Sweet vs Sharp — 4:1
            </h3>
            <p className="text-[12px] text-[var(--ink-muted)] mt-1">156 validating, soft messages vs 39 sharp, punitive ones. That ratio creates a powerful trauma bond — enough warmth to stay, enough sting to stay anxious.</p>

            <div className="mt-4 h-[180px] w-full relative">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={donutData} dataKey="value" cx="50%" cy="50%" innerRadius={56} outerRadius={78} paddingAngle={4} stroke="none">
                    {donutData.map((e, i) => <Cell key={i} fill={e.color} />)}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                <p className="serif text-[28px] font-bold leading-none">4:1</p>
                <p className="text-[10px] uppercase tracking-[0.12em] opacity-60 font-semibold mt-1">Ratio</p>
              </div>
            </div>

            <div className="mt-2 space-y-2">
              <div className="flex items-center justify-between text-[12px] rounded-[10px] bg-[#d8f3dc]/60 border border-[#b7e4c7]/60 px-3 py-2.5">
                <span className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-full bg-[#2a9d8f]" /> Sweet / Validation</span>
                <span className="font-semibold">156</span>
              </div>
              <div className="flex items-center justify-between text-[12px] rounded-[10px] bg-[#fde8e1]/80 border border-[#f8c4b4]/60 px-3 py-2.5">
                <span className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-full bg-[#e76f51]" /> Sharp / Tests & Punishment</span>
                <span className="font-semibold">39</span>
              </div>
              <p className="text-[11px] leading-[1.5] text-[var(--ink-muted)] pt-2">
                Intermittent reinforcement research: variable rewards at ~20% punishment rate maximize time-on-device. Your 80/20 split mirrors slot-machine design. Detox was the only circuit breaker.
              </p>
            </div>
          </section>
        </div>

        {/* Loop */}
        <section className="mt-6 rounded-[20px] bg-[var(--surface)] border border-[var(--border)] shadow-[var(--shadow)] p-6 md:p-8">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h3 className="serif text-[18px] font-semibold flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-[#264653] text-white flex items-center justify-center text-[12px]">4</span>
              4-Step Control Loop — You are here: Hard Block
            </h3>
            <span className="text-[11px] px-3 py-1 rounded-full bg-[#264653] text-white">Current: Punishment + Door Ajar</span>
          </div>

          <div className="mt-8 grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4 relative">
            {/* connecting line desktop */}
            <div className="hidden md:block absolute top-[28px] left-[12%] right-[12%] h-[2px] bg-[var(--border)]" />

            {[
              { step: 1, title: "Breadcrumbing", desc: "Low investment signals, sweet nothings. Keeps hope alive.", icon: "◐", color: "#2a9d8f", status: "done" },
              { step: 2, title: "Testing", desc: "Secret account, riddles, identity reveal. Checks compliance.", icon: "◑", color: "#6c5ce7", status: "done" },
              { step: 3, title: "Punishment", desc: "Hard Block #2 + hide. Withdrawal of access = power move.", icon: "✕", color: "#264653", status: "active" },
              { step: 4, title: "Door Ajar", desc: "Partial block leaves a crack. You can still see → you still check.", icon: "◒", color: "#e76f51", status: "next" },
            ].map(s => (
              <div key={s.step} className={`relative rounded-[16px] border p-4 md:p-5 transition-all ${s.status === "active" ? "bg-[#264653] text-white border-[#264653] shadow-[0_10px_30px_rgba(38,70,83,0.25)] scale-[1.02]" : "bg-[var(--surface-2)] border-[var(--border)]"}`}>
                <div className="flex items-center justify-between">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-[13px] font-bold ${s.status === "active" ? "bg-white text-[#264653]" : "bg-white border border-[var(--border)]"}`} style={{ color: s.status !== "active" ? s.color : undefined }}>{s.icon}</div>
                  <span className={`text-[10px] uppercase tracking-[0.12em] font-semibold px-2 py-0.5 rounded-full ${s.status === "active" ? "bg-white/15 text-white" : "bg-white border border-[var(--border)] text-[var(--ink-muted)]"}`}>{s.status}</span>
                </div>
                <p className={`mt-4 text-[13px] font-semibold ${s.status === "active" ? "text-white" : ""}`}>{s.step}. {s.title}</p>
                <p className={`mt-1.5 text-[12px] leading-[1.5] ${s.status === "active" ? "text-white/70" : "text-[var(--ink-muted)]"}`}>{s.desc}</p>
                {s.status === "active" && <div className="mt-4 text-[11px] px-2.5 py-1 rounded-full bg-[#e76f51] text-white inline-block">You are here →</div>}
              </div>
            ))}
          </div>

          <div className="mt-6 rounded-[12px] bg-[#fdfbf7] border border-dashed border-[var(--border)] p-4 flex gap-3">
            <span className="text-[16px]">💡</span>
            <p className="text-[12px] leading-[1.6] text-[var(--ink-muted)]">
              <span className="font-semibold text-[var(--ink)]">Pattern recognition is the exit.</span> Breadcrumbing → Testing → Punishment → Door Ajar is a closed loop. The “door ajar” is intentional — partial blocks maintain your attention without requiring investment. Closing that crack (mute, remove, no-check rule) breaks the cycle faster than willpower.
            </p>
          </div>
        </section>

        {/* Add custom notes */}
        <section className="mt-6 rounded-[20px] bg-[var(--surface)] border border-[var(--border)] shadow-[var(--shadow)] p-6 md:p-8">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <h3 className="serif text-[18px] font-semibold">Add your own markers</h3>
              <p className="text-[12px] text-[var(--ink-muted)] mt-1 max-w-[520px]">Therapy worksheet style — add dates and feelings that matter to you. They appear on the timeline and emotional curve. Stored privately.</p>
            </div>
            <div className="text-[11px] opacity-60">Python-style note log: {allEvents.length} events total</div>
          </div>

          <div className="mt-5 grid md:grid-cols-[160px_1fr_auto] gap-3 items-end">
            <div>
              <label className="text-[11px] uppercase tracking-[0.08em] font-semibold opacity-60">Date</label>
              <input type="date" value={newDate} onChange={e => setNewDate(e.target.value)} className="mt-1 w-full rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)] px-3 py-2.5 text-[13px] outline-none focus:ring-2 focus:ring-[#2a9d8f]/30 focus:border-[#2a9d8f]" />
            </div>
            <div>
              <label className="text-[11px] uppercase tracking-[0.08em] font-semibold opacity-60">Note / feeling (max 120 chars)</label>
              <input type="text" maxLength={120} value={newNote} onChange={e => setNewNote(e.target.value)} placeholder="e.g., Felt calm, didn't check. / Saw riddle again." className="mt-1 w-full rounded-[10px] border border-[var(--border)] bg-[var(--surface-2)] px-3 py-2.5 text-[13px] outline-none focus:ring-2 focus:ring-[#2a9d8f]/30 focus:border-[#2a9d8f]" />
            </div>
            <button onClick={handleAddNote} disabled={busy} className="h-[42px] px-5 rounded-[10px] bg-[#264653] text-white text-[13px] font-semibold hover:bg-[#1d3640] transition disabled:opacity-50">
              {busy ? "Saving…" : "+ Add to timeline"}
            </button>
          </div>
          {saveError && <p className="mt-3 text-[12px] text-[#a43d24] bg-[#fde8e1] border border-[#f8c4b4] px-3 py-2 rounded-[10px]">{saveError}</p>}
          {saveInfo && <p className="mt-3 text-[12px] text-[#1d6a5f] bg-[#d8f3dc] border border-[#b7e4c7] px-3 py-2 rounded-[10px]">{saveInfo}</p>}

          {customNotes.length > 0 && (
            <div className="mt-6">
              <p className="text-[11px] uppercase tracking-[0.1em] font-semibold opacity-60 mb-2">Your added markers</p>
              <div className="flex flex-wrap gap-2">
                {customNotes.map(n => (
                  <span key={n.id} className="inline-flex items-center gap-2 text-[12px] px-3 py-1.5 rounded-full bg-[var(--surface-2)] border border-[var(--border)]">
                    <span className="font-medium">{n.value.date}</span>
                    <span className="opacity-70">{n.value.note}</span>
                    <button onClick={() => handleDeleteNote(n.id)} className="ml-1 w-4 h-4 rounded-full bg-[#fde8e1] text-[#a43d24] flex items-center justify-center text-[10px]">✕</button>
                  </span>
                ))}
              </div>
            </div>
          )}
        </section>

        {/* Footer */}
        <div className="mt-8 text-center text-[11px] text-[var(--ink-muted)] leading-relaxed">
          <p>Made as a private therapeutic visualizer. No data leaves your device except your private notes.</p>
          <p className="mt-1 opacity-60">Teal #2a9d8f = growth • Coral #e76f51 = punishment • Dark #264653 = hard block • Light green #d8f3dc = detox healing zone</p>
        </div>
      </main>
    </div>
  );
}
