import { useEffect, useMemo, useState } from "react";

// Types
type EgoState = "nurturing" | "rebellious" | "adult";

type TaskDef = {
  id: string;
  text: string;
  ego: EgoState;
  isCustom?: boolean;
};

type SadHour = {
  note: string;
  date: string; // ISO date
  createdAt: number;
};

type Completion = {
  taskId: string;
  taskText: string;
  ego: EgoState;
  date: string; // YYYY-MM-DD
  createdAt: number;
};

type Reflection = {
  text: string;
  date: string;
};

type CustomTask = {
  text: string;
  ego: EgoState;
  date: string;
};

// Default library - therapist-aligned
const DEFAULT_TASKS: TaskDef[] = [
  // Nurturing Parent - soft green
  { id: "np1", text: "Make warm tea and hold it with both hands for 2 min", ego: "nurturing" },
  { id: "np2", text: 'Write: "What would a kind mother say to me right now?"', ego: "nurturing" },
  { id: "np3", text: "Self-hug for 20 seconds — really feel it", ego: "nurturing" },
  { id: "np4", text: "Cook a nourishing meal slowly, no rush", ego: "nurturing" },
  { id: "np5", text: "Lotion + massage your hands like you love them", ego: "nurturing" },
  { id: "np6", text: "Light a candle and say one kind thing out loud", ego: "nurturing" },
  // Rebellious Child - sunny yellow
  { id: "rc1", text: "Play loud music and dance badly for 1 song", ego: "rebellious" },
  { id: "rc2", text: "Say NO to one small thing today (and enjoy it)", ego: "rebellious" },
  { id: "rc3", text: "Draw / scribble without rules for 3 minutes", ego: "rebellious" },
  { id: "rc4", text: 'Do something "useless" just for fun', ego: "rebellious" },
  { id: "rc5", text: "Wear something that feels 100% YOU", ego: "rebellious" },
  { id: "rc6", text: "Send a silly voice note to someone safe", ego: "rebellious" },
  // Adult - sky blue
  { id: "ad1", text: "5-4-3-2-1 grounding: 5 see, 4 touch, 3 hear, 2 smell, 1 taste", ego: "adult" },
  { id: "ad2", text: "Fact-check the critical thought: what is true right now?", ego: "adult" },
  { id: "ad3", text: "One small adult task: water plant, tidy desk, pay bill", ego: "adult" },
  { id: "ad4", text: "Write: What I control vs what I don't control", ego: "adult" },
  { id: "ad5", text: "10-min walk noticing 3 new things you've never seen", ego: "adult" },
  { id: "ad6", text: "Set a 25-min timer and do just one thing", ego: "adult" },
];

const EGO_META: Record<EgoState, { label: string; short: string; color: string; deep: string; border: string; emoji: string; desc: string }> = {
  nurturing: {
    label: "NURTURING PARENT",
    short: "Nurturing Parent",
    color: "var(--np)",
    deep: "var(--np-deep)",
    border: "var(--np-border)",
    emoji: "🌿",
    desc: "warm, caring to self — the voice you needed to hear",
  },
  rebellious: {
    label: "REBELLIOUS CHILD",
    short: "Rebellious Child",
    color: "var(--rc)",
    deep: "var(--rc-deep)",
    border: "var(--rc-border)",
    emoji: "☀️",
    desc: "free, playful, boundary-setting — your aliveness",
  },
  adult: {
    label: "ADULT",
    short: "Adult",
    color: "var(--ad)",
    deep: "var(--ad-deep)",
    border: "var(--ad-border)",
    emoji: "🌊",
    desc: "grounded, here-and-now — clear and kind problem-solving",
  },
};

// API helpers
async function api(action: string, args: any) {
  const res = await fetch("actions", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ action, args }),
  });
  const json = await res.json();
  if (!res.ok || json.error) throw new Error(json.error || "API error");
  return json.data;
}

function todayISO() {
  return new Date().toISOString().slice(0, 10);
}
function todayDisplay() {
  return new Date().toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" });
}

export default function App() {
  const [sadHours, setSadHours] = useState<{ id: string; value: SadHour }[]>([]);
  const [completions, setCompletions] = useState<{ id: string; value: Completion }[]>([]);
  const [customTasks, setCustomTasks] = useState<{ id: string; value: CustomTask }[]>([]);
  const [reflections, setReflections] = useState<{ id: string; value: Reflection }[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [showSadModal, setShowSadModal] = useState(false);
  const [sadNote, setSadNote] = useState("");
  const [reflectionInput, setReflectionInput] = useState("");
  const [customInputs, setCustomInputs] = useState<Record<EgoState, string>>({ nurturing: "", rebellious: "", adult: "" });
  const [filterEgo, setFilterEgo] = useState<EgoState | "all">("all");
  const [toast, setToast] = useState<string | null>(null);

  // Load
  useEffect(() => {
    (async () => {
      try {
        const [s, c, ct, r] = await Promise.all([
          api("records.list", { collection: "sad_hours", limit: 100 }),
          api("records.list", { collection: "completions", limit: 100 }),
          api("records.list", { collection: "custom_tasks", limit: 100 }),
          api("records.list", { collection: "reflections", limit: 100 }),
        ]);
        setSadHours(s.records || []);
        setCompletions(c.records || []);
        setCustomTasks(ct.records || []);
        setReflections(r.records || []);
      } catch (e) {
        console.warn("api load failed", e);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const allTasks: TaskDef[] = useMemo(() => {
    const customs: TaskDef[] = customTasks.map((ct) => ({
      id: ct.id,
      text: ct.value.text,
      ego: ct.value.ego,
      isCustom: true,
    }));
    return [...DEFAULT_TASKS, ...customs];
  }, [customTasks]);

  const todayStr = todayISO();
  const todaysSad = sadHours.filter((s) => s.value.date === todayStr);
  const todaysCompletions = completions.filter((c) => c.value.date === todayStr);
  const todaysReflection = reflections.find((r) => r.value.date === todayStr);

  const required = todaysSad.length * 5;
  const done = todaysCompletions.length;
  const ratio = required === 0 ? (done > 0 ? 100 : 0) : Math.min(100, Math.round((done / required) * 100));
  const remaining = Math.max(0, required - done);

  const egoCounts = useMemo(() => {
    const counts: Record<EgoState, number> = { nurturing: 0, rebellious: 0, adult: 0 };
    todaysCompletions.forEach((c) => {
      counts[c.value.ego] += 1;
    });
    return counts;
  }, [todaysCompletions]);

  const streak = useMemo(() => {
    // simple streak: consecutive days up to today where completions >= sad*5 and at least one sad or completion
    const byDate: Record<string, { sad: number; comp: number }> = {};
    sadHours.forEach((s) => {
      const d = s.value.date;
      if (!byDate[d]) byDate[d] = { sad: 0, comp: 0 };
      byDate[d].sad += 1;
    });
    completions.forEach((c) => {
      const d = c.value.date;
      if (!byDate[d]) byDate[d] = { sad: 0, comp: 0 };
      byDate[d].comp += 1;
    });
    let streak = 0;
    let cursor = new Date();
    for (let i = 0; i < 30; i++) {
      const iso = cursor.toISOString().slice(0, 10);
      const entry = byDate[iso];
      if (!entry) {
        // if today missing, don't break immediately? but for streak we need continuous
        if (i === 0) { cursor.setDate(cursor.getDate() - 1); continue; }
        break;
      }
      const need = entry.sad * 5;
      if (need === 0) {
        if (entry.comp > 0) streak += 1;
        else break;
      } else {
        if (entry.comp >= need) streak += 1;
        else break;
      }
      cursor.setDate(cursor.getDate() - 1);
    }
    return streak;
  }, [sadHours, completions]);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2200);
  };

  const reloadAll = async () => {
    const [s, c, ct, r] = await Promise.all([
      api("records.list", { collection: "sad_hours", limit: 100 }),
      api("records.list", { collection: "completions", limit: 100 }),
      api("records.list", { collection: "custom_tasks", limit: 100 }),
      api("records.list", { collection: "reflections", limit: 100 }),
    ]);
    setSadHours(s.records || []);
    setCompletions(c.records || []);
    setCustomTasks(ct.records || []);
    setReflections(r.records || []);
  };

  const handleAddSadHour = async () => {
    if (!sadNote.trim() && todaysSad.length === 0) {
      // allow empty but encourage
    }
    setBusy(true);
    try {
      const idKey = `sad-${Date.now()}`;
      await api("records.create", {
        collection: "sad_hours",
        value: { note: sadNote.trim() || "A hard hour", date: todayStr, createdAt: Date.now() } as SadHour,
        idempotency_key: idKey,
      });
      setSadNote("");
      setShowSadModal(false);
      await reloadAll();
      showToast("Logged. Be gentle with yourself — now 5 small kindnesses?");
    } catch (e: any) {
      showToast(e.message || "Could not save");
    } finally {
      setBusy(false);
    }
  };

  const handleComplete = async (task: TaskDef) => {
    // prevent duplicate completion same task same day?
    const already = todaysCompletions.some((c) => c.value.taskId === task.id);
    if (already) {
      showToast("Already nourished with this today — try another");
      return;
    }
    setBusy(true);
    try {
      const idKey = `comp-${task.id}-${todayStr}-${Date.now()}`;
      await api("records.create", {
        collection: "completions",
        value: {
          taskId: task.id,
          taskText: task.text,
          ego: task.ego,
          date: todayStr,
          createdAt: Date.now(),
        } as Completion,
        idempotency_key: idKey,
      });
      await reloadAll();
      showToast(`+1 ${EGO_META[task.ego].short} nourished`);
    } catch (e: any) {
      showToast(e.message);
    } finally {
      setBusy(false);
    }
  };

  const handleUndoCompletion = async (id: string) => {
    setBusy(true);
    try {
      await api("records.delete", { collection: "completions", id });
      await reloadAll();
      showToast("Undone — it's okay to change your mind");
    } catch (e: any) {
      showToast(e.message);
    } finally {
      setBusy(false);
    }
  };

  const handleAddCustomTask = async (ego: EgoState) => {
    const text = customInputs[ego].trim();
    if (!text) return;
    if (text.length > 200) {
      showToast("Keep it short and sweet (200 chars)");
      return;
    }
    setBusy(true);
    try {
      await api("records.create", {
        collection: "custom_tasks",
        value: { text, ego, date: todayStr } as CustomTask,
        idempotency_key: `ct-${ego}-${Date.now()}-${text.slice(0,10)}`,
      });
      setCustomInputs((prev) => ({ ...prev, [ego]: "" }));
      await reloadAll();
      showToast(`Added to ${EGO_META[ego].short}`);
    } catch (e: any) {
      showToast(e.message);
    } finally {
      setBusy(false);
    }
  };

  const handleSaveReflection = async () => {
    if (!reflectionInput.trim()) return;
    setBusy(true);
    try {
      if (todaysReflection) {
        await api("records.replace", {
          collection: "reflections",
          id: todaysReflection.id,
          value: { text: reflectionInput.trim(), date: todayStr },
        });
      } else {
        await api("records.create", {
          collection: "reflections",
          value: { text: reflectionInput.trim(), date: todayStr },
          idempotency_key: `ref-${todayStr}`,
        });
      }
      await reloadAll();
      showToast("Reflection saved — beautiful noticing");
    } catch (e: any) {
      showToast(e.message);
    } finally {
      setBusy(false);
    }
  };

  useEffect(() => {
    if (todaysReflection && !reflectionInput) {
      setReflectionInput(todaysReflection.value.text);
    }
  }, [todaysReflection]);

  // Donut data
  const totalEgo = egoCounts.nurturing + egoCounts.rebellious + egoCounts.adult;
  const donutSegments = useMemo(() => {
    const colors = { nurturing: "#8BC48A", rebellious: "#F5D547", adult: "#7BC4E6" };
    if (totalEgo === 0) return [];
    const entries: { ego: EgoState; pct: number; color: string }[] = [
      { ego: "nurturing", pct: egoCounts.nurturing / totalEgo, color: colors.nurturing },
      { ego: "rebellious", pct: egoCounts.rebellious / totalEgo, color: colors.rebellious },
      { ego: "adult", pct: egoCounts.adult / totalEgo, color: colors.adult },
    ].filter((e) => e.pct > 0);
    let offset = 0;
    return entries.map((e) => {
      const seg = { ...e, offset };
      offset += e.pct;
      return seg;
    });
  }, [egoCounts, totalEgo]);

  return (
    <div
      data-safe-area-inset-root
      style={{ boxSizing: "border-box", paddingTop: "var(--safe-area-inset-top)", minHeight: "100vh" }}
      className="w-full bg-[var(--bg)] overflow-x-clip"
    >
      {/* Sticky header */}
      <header
        data-safe-area-sticky-top
        style={{ top: "var(--safe-area-inset-top)" }}
        className="sticky z-30 backdrop-blur-xl border-b border-[var(--line)] bg-[var(--bg)]/80"
      >
        <div className="mx-auto max-w-[1080px] px-5 sm:px-8 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-[var(--ink)] text-[var(--bg)] grid place-items-center font-bold text-[14px]">5:1</div>
            <div className="leading-none">
              <div className="text-[11px] tracking-[0.18em] uppercase opacity-60 font-semibold">TA Healing Ratio</div>
              <div className="text-[15px] font-semibold -mt-0.5">Detox Tracker</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="hidden sm:flex items-center gap-2 text-[12px] px-3 py-1.5 rounded-full bg-[var(--surface)] border border-[var(--line)]">
              <span className="w-2 h-2 rounded-full bg-[#8BC48A] animate-pulse" />
              Streak {streak} day{streak !== 1 ? "s" : ""}
            </div>
            <button
              onClick={() => setShowSadModal(true)}
              className="rounded-full bg-[var(--ink)] text-[var(--bg)] px-4 py-2 text-[13px] font-medium hover:opacity-90 transition"
            >
              + Sad hour
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-[1080px] px-5 sm:px-8 pb-24 pt-6 sm:pt-10">
        {/* Hero */}
        <div className="grid lg:grid-cols-[1.2fr_0.8fr] gap-6 sm:gap-8 items-start">
          <div>
            <h1 className="text-[34px] sm:text-[52px] leading-[0.95] font-bold tracking-[-0.02em]">
              5:1 Healing Ratio —<br />
              <span className="font-light italic">Your TA-Based Detox</span>
            </h1>
            <div className="mt-5 p-4 sm:p-5 rounded-[20px] bg-[var(--surface)] border border-[var(--line)] shadow-[var(--shadow)]">
              <p className="text-[15px] leading-[1.6] text-[var(--ink-soft)]">
                When 1 sad hour / hard feeling hits, we don't argue with it. We <span className="text-[var(--ink)] font-semibold">fill</span> around it with
                5 small fulfilling tasks. Your therapist named it:{" "}
                <span className="inline-flex flex-wrap gap-1.5 mt-1">
                  <span className="px-2 py-0.5 rounded-full bg-[var(--np)] border border-[var(--np-border)] text-[12px]">More Nurturing Parent</span>
                  <span className="px-2 py-0.5 rounded-full bg-[var(--rc)] border border-[var(--rc-border)] text-[12px]">More Rebellious Child</span>
                  <span className="px-2 py-0.5 rounded-full bg-[var(--ad)] border border-[var(--ad-border)] text-[12px]">More Adult</span>
                  <span className="px-2 py-0.5 rounded-full bg-[var(--critical)] border border-[#f0c2bf] text-[12px] line-through decoration-[var(--ink-soft)]">Less Critical Parent</span>
                </span>
              </p>
              <div className="mt-4 text-[13px] font-medium tracking-wide bg-[var(--surface-2)] border border-[var(--line)] rounded-full px-4 py-2 inline-block">
                “Less Critical Parent = More Nurturing Parent + Rebellious Child + Adult”
              </div>
            </div>

            {/* Big counter */}
            <div className="mt-6 grid grid-cols-1 sm:grid-cols-[1fr_auto] gap-4 items-stretch">
              <div className="rounded-[24px] bg-[var(--surface)] border border-[var(--line)] p-5 sm:p-6 shadow-[var(--shadow)]">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <div className="text-[12px] tracking-[0.14em] uppercase opacity-60 font-semibold">{todayDisplay()}</div>
                    <div className="mt-1 text-[22px] sm:text-[26px] font-semibold leading-tight">
                      Today I had <span className="inline-block px-2 rounded-full bg-[var(--critical)] border border-[#f0c2bf]">{todaysSad.length} sad hour{todaysSad.length !== 1 ? "s" : ""}</span>,
                      I did <span className="inline-block px-2 rounded-full bg-[var(--surface-2)] border border-[var(--line)]">{done} fulfilling</span> tasks
                    </div>
                    <div className="mt-2 text-[13px] text-[var(--ink-soft)]">
                      Aim: {required === 0 ? "5 tasks to keep your cup full" : `${required} tasks (5 × ${todaysSad.length})`}. {remaining > 0 ? `${remaining} more to feel balanced.` : "You filled it. Breathe."}
                    </div>
                  </div>
                  <div className="hidden sm:grid w-14 h-14 rounded-full bg-[var(--surface-2)] border border-[var(--line)] place-items-center text-[22px]">🫶</div>
                </div>

                {/* Progress */}
                <div className="mt-5">
                  <div className="flex justify-between text-[11px] uppercase tracking-wide opacity-60 font-semibold mb-2">
                    <span>Healing progress</span>
                    <span>{ratio}%</span>
                  </div>
                  <div className="h-[14px] w-full rounded-full bg-[var(--surface-2)] border border-[var(--line)] overflow-hidden p-1">
                    <div
                      className="h-full rounded-full transition-all duration-700"
                      style={{
                        width: `${ratio}%`,
                        background: `linear-gradient(90deg, var(--np) 0%, var(--rc) 50%, var(--ad) 100%)`,
                      }}
                    />
                  </div>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {todaysSad.slice(-3).map((s) => (
                      <span key={s.id} className="text-[11px] px-2.5 py-1 rounded-full bg-[#f8d7d5]/60 border border-[#f0c2bf] truncate max-w-[220px]">
                        • {s.value.note}
                      </span>
                    ))}
                    {todaysSad.length === 0 && (
                      <span className="text-[11px] px-2.5 py-1 rounded-full bg-[var(--surface-2)] border border-[var(--line)]">No sad hours logged yet — gentle day</span>
                    )}
                  </div>
                </div>
              </div>

              {/* Donut */}
              <div className="rounded-[24px] bg-[var(--surface)] border border-[var(--line)] p-5 shadow-[var(--shadow)] min-w-[220px] flex flex-col items-center justify-center">
                <div className="text-[11px] tracking-[0.14em] uppercase opacity-60 font-semibold mb-3">Ego states nurtured today</div>
                <div className="relative w-[140px] h-[140px]">
                  <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
                    <circle cx="50" cy="50" r="32" fill="none" stroke="var(--surface-2)" strokeWidth="16" />
                    {donutSegments.length > 0 ? (
                      donutSegments.map((seg) => (
                        <circle
                          key={seg.ego}
                          cx="50"
                          cy="50"
                          r="32"
                          fill="none"
                          stroke={seg.color}
                          strokeWidth="16"
                          strokeDasharray={`${seg.pct * 201} 201`}
                          strokeDashoffset={`${-seg.offset * 201}`}
                          strokeLinecap="round"
                          className="transition-all duration-700"
                        />
                      ))
                    ) : (
                      <circle cx="50" cy="50" r="32" fill="none" stroke="var(--line)" strokeWidth="16" strokeDasharray="4 8" opacity={0.6} />
                    )}
                  </svg>
                  <div className="absolute inset-0 grid place-items-center">
                    <div className="text-center">
                      <div className="text-[26px] font-bold leading-none">{totalEgo}</div>
                      <div className="text-[10px] uppercase tracking-wide opacity-60">tasks</div>
                    </div>
                  </div>
                </div>
                <div className="mt-3 w-full space-y-1.5">
                  {(Object.keys(EGO_META) as EgoState[]).map((k) => (
                    <div key={k} className="flex items-center justify-between text-[12px]">
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full" style={{ background: k === "nurturing" ? "#8BC48A" : k === "rebellious" ? "#F5D547" : "#7BC4E6" }} />
                        <span className="font-medium">{EGO_META[k].short}</span>
                      </div>
                      <span className="opacity-70">{egoCounts[k]}</span>
                    </div>
                  ))}
                </div>
                {totalEgo === 0 && <div className="mt-2 text-[11px] opacity-60 text-center">Pick 1 task to start the donut</div>}
              </div>
            </div>

            {remaining > 0 && required > 0 && (
              <div className="mt-4 rounded-[16px] border border-[var(--line)] bg-[var(--surface)] px-4 py-3 flex items-center justify-between gap-3">
                <div className="text-[13px]">
                  <span className="font-semibold">Gentle nudge:</span> you have {remaining} fulfilling tasks waiting to balance today’s hard hours.
                </div>
                <button
                  onClick={() => document.getElementById("task-library")?.scrollIntoView({ behavior: "smooth" })}
                  className="shrink-0 rounded-full bg-[var(--ink)] text-[var(--bg)] px-3 py-1.5 text-[12px]"
                >
                  Pick now
                </button>
              </div>
            )}
          </div>

          {/* Right sticky note */}
          <div className="lg:sticky lg:top-[84px] space-y-4">
            <div className="rounded-[24px] bg-[#fffdf6] dark:bg-[var(--surface)] border border-[#fde68a] p-5 shadow-[var(--shadow)]">
              <div className="text-[12px] tracking-[0.14em] uppercase font-semibold opacity-60">How this works</div>
              <ol className="mt-3 space-y-2.5 text-[13px] leading-[1.5] list-decimal pl-4">
                <li>When a sad / critical hour comes, tap <b>+ Sad hour</b> + quick note.</li>
                <li>Your ratio becomes 5:1 — choose 5 tiny kind actions.</li>
                <li>Mix the three ego states, don't just do one.</li>
                <li>Check them off. Watch the progress fill.</li>
              </ol>
              <div className="mt-4 text-[12px] p-3 rounded-[12px] bg-[var(--rc)] border border-[var(--rc-border)]">
                Tip from therapy: <span className="font-semibold">Less Critical Parent</span> isn't about fighting it. It's about feeding the other three until they get louder.
              </div>
            </div>

            <div className="rounded-[24px] bg-[var(--surface)] border border-[var(--line)] p-5 shadow-[var(--shadow)]">
              <div className="text-[12px] tracking-[0.14em] uppercase font-semibold opacity-60 mb-3">Recent completions</div>
              {loading ? (
                <div className="text-[13px] opacity-60">Loading…</div>
              ) : todaysCompletions.length === 0 ? (
                <div className="text-[13px] opacity-60">Nothing yet today. Pick one below — make it easy.</div>
              ) : (
                <div className="space-y-2 max-h-[260px] overflow-auto pr-1">
                  {todaysCompletions
                    .slice()
                    .sort((a, b) => b.value.createdAt - a.value.createdAt)
                    .map((c) => (
                      <div key={c.id} className="group flex items-start justify-between gap-2 p-2.5 rounded-[12px] border border-[var(--line)] bg-[var(--surface-2)]">
                        <div className="flex gap-2">
                          <span
                            className="mt-0.5 w-5 h-5 rounded-full grid place-items-center text-[10px] shrink-0"
                            style={{ background: EGO_META[c.value.ego].color, border: `1px solid ${EGO_META[c.value.ego].border}` }}
                          >
                            {EGO_META[c.value.ego].emoji}
                          </span>
                          <span className="text-[12.5px] leading-[1.4]">{c.value.taskText}</span>
                        </div>
                        <button
                          onClick={() => handleUndoCompletion(c.id)}
                          className="opacity-0 group-hover:opacity-100 text-[11px] underline shrink-0"
                        >
                          undo
                        </button>
                      </div>
                    ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Filter + library */}
        <div id="task-library" className="mt-12 sm:mt-16">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h2 className="text-[28px] sm:text-[32px] leading-none font-bold">Task library</h2>
            <div className="flex items-center gap-1 p-1 rounded-full bg-[var(--surface)] border border-[var(--line)]">
              {(["all", "nurturing", "rebellious", "adult"] as const).map((f) => (
                <button
                  key={f}
                  onClick={() => setFilterEgo(f as any)}
                  className={`px-3 py-1.5 rounded-full text-[12px] font-medium transition ${filterEgo === f ? "bg-[var(--ink)] text-[var(--bg)]" : "opacity-70 hover:opacity-100"}`}
                >
                  {f === "all" ? "All" : EGO_META[f as EgoState].short}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-6 grid lg:grid-cols-3 gap-5 sm:gap-6">
            {(Object.keys(EGO_META) as EgoState[]).map((ego) => {
              const meta = EGO_META[ego];
              const visible = filterEgo === "all" || filterEgo === ego;
              if (!visible) return null;
              const tasks = allTasks.filter((t) => t.ego === ego);
              return (
                <section
                  key={ego}
                  className="rounded-[24px] border p-4 sm:p-5 shadow-[var(--shadow)]"
                  style={{ background: meta.color, borderColor: meta.border }}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-[18px]">{meta.emoji}</span>
                        <h3 className="text-[15px] font-bold tracking-[0.08em]">{meta.label}</h3>
                      </div>
                      <p className="mt-1 text-[12px] leading-[1.4] opacity-80 max-w-[26ch]">{meta.desc}</p>
                    </div>
                    <div className="text-[11px] font-semibold px-2 py-1 rounded-full bg-white/70 border border-black/10">{tasks.length}</div>
                  </div>

                  <div className="mt-4 space-y-2.5">
                    {tasks.map((task) => {
                      const isDone = todaysCompletions.some((c) => c.value.taskId === task.id);
                      return (
                        <label
                          key={task.id}
                          className={`group flex items-start gap-3 p-3 rounded-[14px] bg-white/85 dark:bg-[var(--surface)]/90 border border-black/5 cursor-pointer transition hover:translate-y-[-1px] hover:shadow-sm ${isDone ? "opacity-60" : ""}`}
                        >
                          <input
                            type="checkbox"
                            checked={isDone}
                            onChange={() => (isDone ? null : handleComplete(task))}
                            disabled={busy || isDone}
                            className="mt-0.5 w-[18px] h-[18px] rounded-[6px] accent-[var(--ink)]"
                          />
                          <span className={`text-[13.5px] leading-[1.45] ${isDone ? "line-through decoration-1" : ""}`}>{task.text}</span>
                          {task.isCustom && (
                            <span className="ml-auto text-[9px] tracking-wide uppercase px-1.5 py-0.5 rounded-full bg-[var(--surface-2)] border border-[var(--line)] shrink-0">custom</span>
                          )}
                        </label>
                      );
                    })}
                  </div>

                  {/* add custom */}
                  <div className="mt-4 flex gap-2">
                    <input
                      value={customInputs[ego]}
                      onChange={(e) => setCustomInputs((p) => ({ ...p, [ego]: e.target.value }))}
                      placeholder={`Add your own ${meta.short} task…`}
                      className="flex-1 min-w-0 rounded-full bg-white/90 dark:bg-[var(--surface)] border border-black/10 px-4 py-2 text-[13px] outline-none focus:ring-2 focus:ring-black/10"
                      onKeyDown={(e) => e.key === "Enter" && handleAddCustomTask(ego)}
                    />
                    <button
                      onClick={() => handleAddCustomTask(ego)}
                      disabled={busy || !customInputs[ego].trim()}
                      className="rounded-full bg-[var(--ink)] text-[var(--bg)] px-4 py-2 text-[12px] font-medium disabled:opacity-40"
                    >
                      Add
                    </button>
                  </div>
                </section>
              );
            })}
          </div>
        </div>

        {/* Reflection */}
        <div className="mt-12 sm:mt-16 grid lg:grid-cols-[0.9fr_1.1fr] gap-6">
          <div className="rounded-[24px] bg-[var(--surface)] border border-[var(--line)] p-5 sm:p-6 shadow-[var(--shadow)]">
            <h3 className="text-[20px] font-bold">Daily reflection</h3>
            <p className="mt-1 text-[13px] text-[var(--ink-soft)] leading-[1.5]">Which Parent / Child / Adult did I nourish today? No judgment, just noticing.</p>
            <textarea
              value={reflectionInput}
              onChange={(e) => setReflectionInput(e.target.value)}
              placeholder="Today I noticed my Nurturing Parent when I… My Rebellious Child felt alive when… My Adult showed up by…"
              className="mt-4 w-full min-h-[140px] rounded-[16px] bg-[var(--surface-2)] border border-[var(--line)] p-4 text-[13.5px] leading-[1.6] outline-none focus:ring-2 focus:ring-black/10 resize-none"
            />
            <div className="mt-3 flex items-center justify-between">
              <span className="text-[11px] opacity-60">{reflectionInput.length}/600</span>
              <button
                onClick={handleSaveReflection}
                disabled={busy || !reflectionInput.trim()}
                className="rounded-full bg-[var(--ink)] text-[var(--bg)] px-5 py-2 text-[13px] font-medium disabled:opacity-40"
              >
                Save reflection
              </button>
            </div>
          </div>

          <div className="rounded-[24px] bg-[var(--ink)] text-[var(--bg)] p-5 sm:p-6 shadow-[var(--shadow)] relative overflow-hidden">
            <div className="absolute -right-16 -top-16 w-64 h-64 rounded-full bg-white/10 blur-2xl" />
            <h3 className="text-[20px] font-bold relative">Therapy reminder</h3>
            <div className="mt-3 space-y-3 text-[13.5px] leading-[1.6] relative text-white/85">
              <p>
                Your Critical Parent learned to protect you. We don’t need to fight it — we make the other rooms in the house brighter.
              </p>
              <div className="grid grid-cols-3 gap-2 text-[11px]">
                <div className="rounded-[14px] bg-white/10 border border-white/15 p-3">
                  <div className="font-bold tracking-wide">NURTURING PARENT</div>
                  <div className="mt-1 opacity-80">Warmth, permission, softness toward self.</div>
                </div>
                <div className="rounded-[14px] bg-white/10 border border-white/15 p-3">
                  <div className="font-bold tracking-wide">REBELLIOUS CHILD</div>
                  <div className="mt-1 opacity-80">Play, desire, saying no with joy.</div>
                </div>
                <div className="rounded-[14px] bg-white/10 border border-white/15 p-3">
                  <div className="font-bold tracking-wide">ADULT</div>
                  <div className="mt-1 opacity-80">Grounding, facts, small doable steps.</div>
                </div>
              </div>
              <div className="mt-2 text-[12px] px-3 py-2 rounded-full bg-white text-black inline-block font-medium">
                Less Critical Parent = More Nurturing Parent + Rebellious Child + Adult
              </div>
            </div>
          </div>
        </div>

        <footer className="mt-16 text-center text-[11px] opacity-50 tracking-wide">Made for gentle healing — 5:1 ratio, not perfection. • Streak counts only when ratio is met</footer>
      </main>

      {/* Sad hour modal */}
      {showSadModal && (
        <div className="fixed inset-0 z-50 grid place-items-center p-4 bg-black/30 backdrop-blur-sm">
          <div className="w-full max-w-[420px] rounded-[24px] bg-[var(--surface)] border border-[var(--line)] shadow-[var(--shadow)] p-5 sm:p-6">
            <div className="flex items-start justify-between gap-3">
              <div>
                <h3 className="text-[20px] font-bold">Log a sad hour</h3>
                <p className="mt-1 text-[13px] text-[var(--ink-soft)]">Name it kindly. No need to explain — just enough so future you remembers.</p>
              </div>
              <button onClick={() => setShowSadModal(false)} className="w-8 h-8 rounded-full bg-[var(--surface-2)] grid place-items-center">✕</button>
            </div>
            <textarea
              value={sadNote}
              onChange={(e) => setSadNote(e.target.value)}
              placeholder="e.g., Critical thoughts after meeting, felt small and tired..."
              className="mt-4 w-full min-h-[90px] rounded-[16px] bg-[var(--surface-2)] border border-[var(--line)] p-4 text-[13px] outline-none focus:ring-2 focus:ring-black/10"
              autoFocus
            />
            <div className="mt-4 flex items-center justify-between">
              <span className="text-[11px] opacity-60">This sets your need to 5 nourishing tasks</span>
              <button
                onClick={handleAddSadHour}
                disabled={busy}
                className="rounded-full bg-[var(--ink)] text-[var(--bg)] px-5 py-2.5 text-[13px] font-medium disabled:opacity-40"
              >
                {busy ? "Saving…" : "Save sad hour"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Toast */}
      {toast && (
        <div className="fixed bottom-5 left-1/2 -translate-x-1/2 z-50 rounded-full bg-[var(--ink)] text-[var(--bg)] px-5 py-2.5 text-[13px] shadow-xl border border-white/10">
          {toast}
        </div>
      )}
    </div>
  );
}
